from rest_framework import serializers
from django.contrib.auth import get_user_model, authenticate
from django.contrib.auth.models import update_last_login
from dj_rest_auth.registration.serializers import RegisterSerializer
from rest_framework_simplejwt.tokens import RefreshToken

from .models import *


# 기본 유저 모델 불러오기
User = get_user_model()

# 회원가입
class CustomRegisterSerializer(RegisterSerializer):

    def get_cleaned_data(self):
        data_dict = super().get_cleaned_data()

        return data_dict

#로그인
class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=50)
    password = serializers.CharField(max_length=30, write_only=True)
    token = serializers.CharField(max_length=255, read_only=True)

    def validate(self, data):
        username = data.get("username")
        password = data.get("password", None)

        print(username)
        print(password)
        user = authenticate(username=username, password=password)
        print(user)
        if user is None:
            return {'username': 'None'}
        try:
            update_last_login(None, user)
            refresh = RefreshToken.for_user(user)
            access = str(refresh.access_token)
            print(access)
        except User.DoesNotExist:
            raise serializers.ValidationError(
                'User with given email and password does not exist'
            )
        return {
            'id': user.id,
            'username': user.username,
            'access': access,
        }

# 사용자 정보 추출
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username')